public class HardArmor extends Clothes{

    public HardArmor(){
        setName("Hard Armor");
        setValue(20);
        setWeight(20.0);
        setProtection(20.0);
    }

    @Override
    public void printInfo() {
        super.printInfo();
    }
}
