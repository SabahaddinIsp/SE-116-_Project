public class TowerShield extends Shields{

    public TowerShield(){
        setName("Tower Shield");
        setWeight(30);
        setValue(15);
        setDamage(15);
    }

    @Override
    public void printInfo() {
        super.printInfo();
    }
}
