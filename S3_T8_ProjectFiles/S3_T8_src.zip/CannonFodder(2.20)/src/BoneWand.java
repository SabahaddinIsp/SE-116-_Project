public class BoneWand extends Wands{

    public BoneWand(){
        setName("Bone Wand");
        setWeight(3);
        setValue(20);
        setDamage(10);
    }

    @Override
    public void printInfo() {
        super.printInfo();
    }
}
