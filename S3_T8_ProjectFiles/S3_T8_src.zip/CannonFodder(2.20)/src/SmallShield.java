public class SmallShield extends Shields{

    public SmallShield(){
        setName("Small Shield");
        setWeight(15);
        setValue(10);
        setDamage(10);
    }

    @Override
    public void printInfo() {
        super.printInfo();
    }
}
