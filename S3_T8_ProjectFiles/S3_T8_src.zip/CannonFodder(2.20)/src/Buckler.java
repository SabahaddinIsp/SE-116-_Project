public class Buckler extends Shields{

    public Buckler(){
        setName("Buckler");
        setWeight(10);
        setValue(5);
        setDamage(5);
    }

    @Override
    public void printInfo() {
        super.printInfo();
    }
}
