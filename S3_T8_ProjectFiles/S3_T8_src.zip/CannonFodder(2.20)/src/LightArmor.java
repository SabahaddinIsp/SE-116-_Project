public class LightArmor extends Clothes{

    LightArmor(){
        setName("Light Armor");
        setWeight(5.0);
        setValue(10);
        setProtection(10.0);
    }

    @Override
    public void printInfo() {
        super.printInfo();
    }
}
