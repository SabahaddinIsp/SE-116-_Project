public class WoodWand extends Wands{

    public WoodWand(){
        setName("Wood Wand");
        setWeight(6);
        setValue(15);
        setDamage(7);

    }

    @Override
    public void printInfo() {
        super.printInfo();
    }
}
