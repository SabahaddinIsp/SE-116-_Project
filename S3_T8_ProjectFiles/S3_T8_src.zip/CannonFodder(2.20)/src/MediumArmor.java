public class MediumArmor extends Clothes{

    public MediumArmor(){
        setName("Medium Armor");
        setValue(15);
        setWeight(10.0);
        setProtection(15.0);
    }

    @Override
    public void printInfo() {
        super.printInfo();
    }
}
