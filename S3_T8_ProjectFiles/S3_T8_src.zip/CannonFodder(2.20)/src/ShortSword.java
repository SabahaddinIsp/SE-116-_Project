public class ShortSword extends Swords {

    public ShortSword(){
        setName("Short Sword");
        setWeight(2.0);
        setValue(10);
        setDamage(5);

    }
    @Override
    public void printInfo() {
        super.printInfo();
    }
}
