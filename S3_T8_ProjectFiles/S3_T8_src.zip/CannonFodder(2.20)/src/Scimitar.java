public class Scimitar extends Swords{

    public Scimitar(){
        setName("Scimitar");
        setWeight(6.0);
        setValue(25);
        setDamage(20);

    }

    @Override
    public void printInfo() {
        super.printInfo();
    }
}
