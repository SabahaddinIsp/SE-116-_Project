public class LongSword extends Swords {

    public LongSword(){
        setName("Long Sword");
        setWeight(4.0);
        setValue(20);
        setDamage(15);

    }

    @Override
    public void printInfo() {
        super.printInfo();
    }
}
